#!/bin/bash

export XDG_RUNTIME_DIR=/run/user/1000

weston --backend=rdp-backend.so --rdp4-key=test/rkey/tls.key --port=8123 --width=2160 --height=1080  --shell=kiosk-shell.so

exit


export XDG_RUNTIME_DIR=/run/user/1000
export WAYLAND_DISPLAY=wayland-0

