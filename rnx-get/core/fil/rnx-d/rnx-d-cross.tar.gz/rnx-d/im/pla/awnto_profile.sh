#!/bin/bash 

export AWNTO=awnto
export PATH=/awnto/im/bin:$PATH
