#!/bin/bash


function set_res()
{

if ! test -f /data/data/com.awnto.rnx.xio/files/home/rnx_k9_autoreso  ; then  return ; fi

reso=$(cat /data/data/com.awnto.rnx.xio/files/home/rnx_k9_autoreso)
echo $reso



cvt_line=$(cvt $reso 30)

export DISPLAY=:1

echo $cvt_line
main_cline=""
((nload = 0))
for i in $cvt_line
do
if((nload == 2));
then
	main_cline+="$i "
fi
if((nload == 1));
then
        ((nload = 2))
fi
if [ $i == "Modeline" ] ;
then
	((nload = 1))
fi

done
echo $main_cline

xrandr --newmode "awnto_1" $main_cline
xrandr --newmode "awnto_2" $main_cline
xrandr --addmode VNC-0 "awnto_1"
xrandr --addmode VNC-0 "awnto_2"

if xrandr --delmode VNC-0 awnto_1
then
echo setting awnto_1
xrandr --rmmode "awnto_1"
xrandr --newmode "awnto_1" $main_cline
xrandr --addmode VNC-0 "awnto_1"
xrandr --output VNC-0 --mode "awnto_1"
else
if xrandr --delmode VNC-0 awnto_2
then
echo setting awnto_2
xrandr --rmmode "awnto_2"
xrandr --newmode "awnto_2" $main_cline
xrandr --addmode VNC-0 "awnto_2"
xrandr --output VNC-0 --mode "awnto_2"
fi
fi


}

last_res=""

while((1==1))
do

reso=$(cat /data/data/com.awnto.rnx.xio/files/home/rnx_k9_autoreso)
#sleep 2

if [[ $reso != $last_res ]] ;
then
	echo "----<< resuluton changed $last_res -> $reso >>----"
	last_res=$reso
	set_res

fi
done
