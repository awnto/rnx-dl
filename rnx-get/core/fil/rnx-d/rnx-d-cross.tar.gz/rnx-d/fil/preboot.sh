#!/data/data/com.awnto.rnx.core/files/usr/kbin/bash

pdir=$HOME/.awnto
pfol=rnx-d
pfll=$pdir/$pfol

mkdir -p $pfll

cd $pdir

log=$pfol/im/vari/lstat.txt

#sleep 2


rm -rf $TMPDIR
mkdir -p $TMPDIR

./$pfol/fil/rcv.sh &
./$pfol/fil/sys.sh &


rnx_tog LOADING




echo "-- configureing --"

#mkdir -p $PREFIX/etc/pulse/
cp -rvf $pfol/im/etc/termux_daemon.conf $PREFIX/etc/pulse/daemon.conf
#cp -rvf $pfol/im/etc/termux_default.pa $PREFIX/etc/pulse/default.pa


#cp -rvf $pfol/fil/pla/fatmx_orc $HOME/fatmx/orc

#cp -rvf $pfol/fil/pla/fatmx_tmx $HOME/fatmx/tmx

cp -rvf $pfol/fil/pla/rogg_rogg $PREFIX/scbin/rogg


echo "--------------"




echo "starting ..."

echo "audio server starting ..."



#$HOME/.fatmx/inn pulseaudio --kill 
#$HOME/.fatmx/inn pulseaudio --start &

rnx_tog STARTING_AUDIO_SERVER
pulseaudio --start &
sleep 1
#$HOME/fatmx/orc

#sleep 5


echo "kill xio if exists"

for xio_ids in `pgrep com.awnto.rnx.xio`
do
	kill $xio_ids
done


#$HOME/.fatmx/inn pulseaudio --start &

echo "Linux services starting ..."
rnx_tog STARTING_RINIX_SERVICES

cp /data/data/com.awnto.rnx.xio/files/home/rnx_k9_reso ./$pfol/im/pla/rnx_k9_reso

./$pfol/fil/im.sh /awnto/im/boot &

#inno-d &



echo "-------------"
echo " End Reached"
echo "-------------"

echo ""
echo ""

while true
do


#$HOME/.fatmx/inn pulseaudio --start &

	sleep 2
	#echo 
done


