#!/data/data/com.awnto.rnx.core/files/usr/kbin/bash

pdir=$HOME/.awnto
pfol=rnx-d
pfll=$pdir/$pfol

mkdir -p $pfll

cd $pdir

log=$pfol/im/vari/lstat.txt





if ./$pfol/fil/dk_install.sh ;
then

	echo accor.. starting
	rnx_tog ACOOR_STARTING
	#exec ./$pfol/fil/preboot.sh > $log
       cd $pdir
        exec ./$pfol/fil/preboot.sh

else

	sleep 2
	rnx_tog RECHECKING_D_INSTALL
	sleep 1
	#exec /data/data/com.awnto.rnx.core/files/assets/data/boot.sh
	cd $pdir
	exec ./$pfol/fil/d_install.sh

fi







