#!/data/data/com.awnto.rnx.core/files/usr/kbin/bash

pdir=$HOME/.awnto
pfol=rnx-d
pfll=$pdir/$pfol

mkdir -p $pfll

cd $pdir


cd $pfol/fil/rcv/var


rm ../inet.sh


((ax_curl=0))

while ((ax_curl==0))
do

	if rogg curl -L --output ../inet.sh https://rnx-dl.awnto.com/rnx-get/core/fil/inet.sh
	then
		((ax_curl=1))
	fi

	sleep 1

done

#rogg curl -L --output ../inet.sh https://rnx-dl.awnto.com/rnx-get/core/fil/inet.sh
chmod 755 ../inet.sh
../inet.sh

../post.sh






