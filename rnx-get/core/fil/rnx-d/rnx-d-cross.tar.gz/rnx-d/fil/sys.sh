#!/data/data/com.awnto.rnx.core/files/usr/kbin/bash


pdir=$HOME/.awnto
pfol=rnx-d
pfll=$pdir/$pfol

mkdir -p $pfll

cd $pdir

mkdir -p tvar
cd tvar

rm -rvf shutdown
rm -rvf reboot
rm -rvf shutpid
rm -rvf shutrepid

while((1==1))
do

if [ -f shutdown ] ;
then
	dae shutpid $pfll/fil/bin/shut_kill
	#$pfll/fil/bin/shut_kill
fi
if [ -f reboot ] ;
then
	dae shutrepid $pfll/fil/bin/shut_kill_reboot
	#$pfll/fil/bin/shut_kill
fi

done
