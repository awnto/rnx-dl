#!/data/data/com.awnto.rnx.core/files/usr/kbin/bash

pdir=$HOME/.awnto
pfol=rnx-d
pfll=$pdir/$pfol

mkdir -p $pfll

cd $pdir

log=$pfol/im/vari/lstat.txt

#sleep 2


	echo "==== Killing ===="
	
	
	echo "kill xio if exists"

for xio_ids in `pgrep com.awnto.rnx.xio`
do
	kill $xio_ids
done

	lock_f=$pfol/im/vari/lock_dae
	
	./$pfol/fil/im.sh /awnto/im/kill -l
	echo "stoping rnx core pulseaudio"
	pulseaudio --kill
	kill `cat $lock_f`
	rm -rf $lock_f
	#echo "xxxxxx" > $lock_f
	
	
	echo "killing done"
	echo "=============="
	
	
exit






