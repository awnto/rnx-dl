#!/data/data/com.awnto.rnx.core/files/usr/kbin/bash

pdir=$HOME/.awnto
pfol=rnx-d
pfll=$pdir/$pfol

mkdir -p $pfll

cd $pdir



DRED='\033[1;31m'
NC='\033[0m'
LGRY='\033[1;30m'
LGRN='\033[1;32m'



echo -n -e "$NC"
echo -n -e ">================<| "$DRED"- O X"$NC" |
|  "$LGRN"RNX Linux"$NC"   /----------/
|-------------/  "
echo -n -e "V`rnx version`"
echo -n -e "
|-------------------------\\
|     "$LGRY"rinix.awnto.com"$NC"     |
|_________________________/
"



echo -n -e "$LGRY"
echo -n -e "   [ RNX Core Edition ]    "
echo -n -e "$NC"


echo -n -e "
"

cat $pfol/fil/rcv/profile.txt


exit
